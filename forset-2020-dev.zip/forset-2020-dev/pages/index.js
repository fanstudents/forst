import IndexPage from 'containers/IndexPage';

export default IndexPage;
