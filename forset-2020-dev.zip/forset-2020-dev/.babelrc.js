const env = require('./config/env.js');
module.exports = {
  presets: ['next/babel'],
  plugins: [
    ['transform-define', env],
    ['babel-plugin-styled-components', {
      'ssr': true,
      'displayName': true,
      'preprocess': false
    }],
    ['module-resolver', {
      'alias': {
        'containers': './src/containers',
        'components': './src/components',
        'utils': './src/utils',
        'vender': './static/vender',
        'images': './static/images',
      }
    }],
    ['transform-decorators-legacy']
  ],
};
